/**
 * Created by h on 25/11/2016.
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.util.*;


public class GUI {
    JTextArea Txt1, RLText,ErrorText;
    JButton Level, Reset, Level2, Level1;
    JButton but1,but2,but3,but4,but5,but6,but7,but8,but9;//level1
    JButton but10,but11,but12,but13,but14,but15,but16,but17,but18,but19,but20,but21,but22,but23,but24,but25;//level2
    Date newDate = new Date();
    JLabel Score,count;
    int i=0;
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            ex.printStackTrace();

        }
        new GUI();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    public GUI() {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                GUIStart();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void GUIStart() {
        JFrame frame3 = new JFrame("Software Engineering Assignment");
        frame3.setSize(350,140);
        frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel upperPanel = new JPanel();
        JPanel centerPanel = new JPanel();
        JPanel lowerPanel = new JPanel();
        frame3.getContentPane().add(upperPanel, "North");
        frame3.getContentPane().add(centerPanel, "Center");
        frame3.getContentPane().add(lowerPanel, "South");
        upperPanel.setSize(500,100);
        upperPanel.setLayout(new FlowLayout());
        centerPanel.setLayout(new FlowLayout());
        lowerPanel.setSize(500,100);
        lowerPanel.setLayout(new BorderLayout());


        RLText = new JTextArea("");
        RLText =new JTextArea(1, 5);
        RLText.setEditable(true);
        RLText.setLineWrap(true);
        RLText.setWrapStyleWord(true);
        JLabel label = new JLabel("Name");
        Level1 = new JButton("Level 1");
        Level2 = new JButton("Level 2");
        ErrorText = new JTextArea("");
        ErrorText=new JTextArea(1, 5);
        ErrorText.setEditable(false);
        ErrorText.setLineWrap(true);
        ErrorText.setWrapStyleWord(true);

        upperPanel.add(label);
        upperPanel.add(RLText);
        centerPanel.add(Level1);
        centerPanel.add(Level2);
        lowerPanel.add(ErrorText,BorderLayout.SOUTH);
        frame3.setVisible(true);
        Level1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        if(RLText.getText().equals("")){
                            ErrorText.setText("Enter Name");
                        }else {
                            Level1();
                            frame3.setVisible(false);
                            frame3.dispose();
                        }
                    }
                });

            }

        });
        Level2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        if(RLText.getText().equals("")){
                            ErrorText.setText("Enter Name");
                        }else {
                            Level2();
                            frame3.setVisible(false);
                            frame3.dispose();
                        }
                    }
                });

            }
        });

    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    private void Level1() {

        JFrame frame = new JFrame("Level 1: "+RLText.getText());
        frame.setSize(1366, 768);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setBackground(Color.DARK_GRAY);
        JPanel leftPanel = new JPanel();
        JPanel rightPanel = new JPanel();
        frame.getContentPane().add(leftPanel, "West");
        frame.getContentPane().add(rightPanel, "East");
        leftPanel.setSize(100, 100);
        leftPanel.setLayout(new GridLayout(5,1));
        rightPanel.setLayout(new GridLayout(3,3));
        leftPanel.setBackground(Color.BLUE);
        rightPanel.setBackground(Color.WHITE);
        Reset = new JButton("Reset");
        Level = new JButton("Select Level");
        Score = new JLabel(" Score");
        count = new JLabel("   "+i);
        Score.setFont (Score.getFont ().deriveFont (30.0f));
        count.setFont (count.getFont ().deriveFont (40.0f));
        but1 = new JButton("2");
        but2 = new JButton("3");
        but3 = new JButton("2");
        but4 = new JButton("2");
        but5 = new JButton("3");
        but6 = new JButton("2");
        but7 = new JButton("1");
        but8 = new JButton("2");
        but9 = new JButton("2");
        but1.setPreferredSize(new Dimension(100,100));
        Level.setPreferredSize(new Dimension(100,5));
        leftPanel.add(Reset);
        leftPanel.add(Level);

        leftPanel.add(Score);
        leftPanel.add(count);

        Txt1 = new JTextArea(30, 38);
        Txt1.setEditable(false);
        Txt1.setLineWrap(true);
        Txt1.setWrapStyleWord(true);
        rightPanel.add(but1);
        rightPanel.add(but2);
        rightPanel.add(but3);
        rightPanel.add(but4);
        rightPanel.add(but5);
        rightPanel.add(but6);
        rightPanel.add(but7);
        rightPanel.add(but8);
        rightPanel.add(but9);
        //rightPanel.add(new JScrollPane(Txt1));
        frame.pack();
        frame.setVisible(true);

        Reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {

                    }
                });
            }
        });

        Level.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        GUIStart();
                        frame.setVisible(false);
                        frame.dispose();
                    }
                });
            }
        });

    }
    private void Level2() {

        JFrame frame = new JFrame("Level 2: "+RLText.getText());
        frame.setSize(1366, 768);
        JPanel leftPanel = new JPanel();
        JPanel rightPanel = new JPanel();
        frame.getContentPane().add(leftPanel, "West");
        frame.getContentPane().add(rightPanel, "East");
        leftPanel.setSize(100, 100);
        leftPanel.setLayout(new GridLayout(5,1));
        rightPanel.setLayout(new GridLayout(4,4));
        leftPanel.setBackground(Color.BLUE);
        rightPanel.setBackground(Color.WHITE);

        Reset = new JButton("Reset");
        Level = new JButton("Select Level");
        Score = new JLabel(" Score");
        count = new JLabel("   "+i);
        Score.setFont (Score.getFont ().deriveFont (30.0f));
        count.setFont (count.getFont ().deriveFont (40.0f));
        but10 = new JButton("1");
        but11= new JButton("1");
        but12= new JButton("2");
        but13= new JButton("1");
        but14= new JButton("2");
        but15= new JButton("3");
        but16= new JButton("3");
        but17= new JButton("2");
        but18= new JButton("4");
        but19 = new JButton("5");
        but20 = new JButton("4");
        but21 = new JButton("2");
        but22= new JButton("3");
        but23= new JButton("4");
        but24= new JButton("3");
        but25= new JButton("2");
        but10.setPreferredSize(new Dimension(100,100));
        Level.setPreferredSize(new Dimension(100,5));
        leftPanel.add(Reset);
        leftPanel.add(Level);

        leftPanel.add(Score);
        leftPanel.add(count);

        rightPanel.add(but10);
        rightPanel.add(but11);
        rightPanel.add(but12);
        rightPanel.add(but13);
        rightPanel.add(but14);
        rightPanel.add(but15);
        rightPanel.add(but16);
        rightPanel.add(but17);
        rightPanel.add(but18);
        rightPanel.add(but19);
        rightPanel.add(but20);
        rightPanel.add(but21);
        rightPanel.add(but22);
        rightPanel.add(but23);
        rightPanel.add(but24);
        rightPanel.add(but25);

        frame.pack();
        frame.setVisible(true);

        Reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {

                    }
                });
            }
        });

        Level.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        GUIStart();
                        frame.setVisible(false);
                        frame.dispose();

                    }
                });
            }
        });

    }
}
