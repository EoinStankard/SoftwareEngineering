/**
 * Created by Eoin on 25/11/2016.
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.util.*;


public class GUI {
    JTextArea RLText,ErrorText;
    JButton Level, Reset, Level2, Level1;
    JButton but1,but2,but3,but4,but5,but6,but7,but8,but9;//level1
    JButton but10,but11,but12,but13,but14,but15,but16,but17,but18,but19,but20,but21,but22,but23,but24,but25;//level2
    JLabel Score,count;
    int i=0;
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            ex.printStackTrace();

        }
        new GUI();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    public GUI() {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                GUIStart();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void GUIStart() {
        JFrame frame3 = new JFrame("Software Engineering Assignment");
        frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame3.setSize(350,140);
        frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel upperPanel = new JPanel();
        JPanel centerPanel = new JPanel();
        JPanel lowerPanel = new JPanel();
        frame3.getContentPane().add(upperPanel, "North");
        frame3.getContentPane().add(centerPanel, "Center");
        frame3.getContentPane().add(lowerPanel, "South");
        upperPanel.setSize(500,100);
        upperPanel.setLayout(new FlowLayout());
        centerPanel.setLayout(new FlowLayout());
        lowerPanel.setSize(500,100);
        lowerPanel.setLayout(new BorderLayout());


        RLText = new JTextArea("");
        RLText =new JTextArea(1, 5);
        RLText.setEditable(true);
        RLText.setLineWrap(true);
        RLText.setWrapStyleWord(true);
        JLabel label = new JLabel("Name*");
        Level1 = new JButton("Level 1");
        Level2 = new JButton("Level 2");
        ErrorText = new JTextArea("");
        ErrorText=new JTextArea(1, 5);
        ErrorText.setEditable(false);
        ErrorText.setLineWrap(true);
        ErrorText.setWrapStyleWord(true);

        upperPanel.add(label);
        upperPanel.add(RLText);
        centerPanel.add(Level1);
        centerPanel.add(Level2);
        lowerPanel.add(ErrorText,BorderLayout.SOUTH);
        frame3.setVisible(true);
        Level1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        if(RLText.getText().equals("")){
                            ErrorText.setText("Enter Name");
                        }else {
                            Level1();
                            frame3.setVisible(false);
                            frame3.dispose();
                        }
                    }
                });

            }

        });
        Level2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        if(RLText.getText().equals("")){
                            ErrorText.setText("Enter Name");
                        }else {
                            Level2();
                            frame3.setVisible(false);
                            frame3.dispose();
                        }
                    }
                });

            }
        });

    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    private void Level1() {

        JFrame frame = new JFrame("Level 1: "+RLText.getText());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1366, 768);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setBackground(Color.DARK_GRAY);
        JPanel leftPanel = new JPanel();
        JPanel rightPanel = new JPanel();
        frame.getContentPane().add(leftPanel, "West");
        frame.getContentPane().add(rightPanel, "East");
        leftPanel.setSize(100, 100);
        leftPanel.setLayout(new GridLayout(5,1));
        rightPanel.setLayout(new GridLayout(3,3));
        leftPanel.setBackground(Color.BLUE);
        rightPanel.setBackground(Color.WHITE);
        Reset = new JButton("Reset");
        Level = new JButton("Select Level");
        Score = new JLabel(" Score");
        count = new JLabel("   "+i);
        Score.setFont (Score.getFont ().deriveFont (30.0f));
        count.setFont (count.getFont ().deriveFont (40.0f));
        but1 = new JButton("");
        but2 = new JButton("");
        but3 = new JButton("");
        but4 = new JButton("");
        but5 = new JButton("");
        but6 = new JButton("");
        but7 = new JButton("");
        but8 = new JButton("");
        but9 = new JButton("");
        but1.setPreferredSize(new Dimension(100,100));
        Level.setPreferredSize(new Dimension(100,5));
        leftPanel.add(Reset);
        leftPanel.add(Level);

        leftPanel.add(Score);
        leftPanel.add(count);

        rightPanel.add(but1);
        rightPanel.add(but2);
        rightPanel.add(but3);
        rightPanel.add(but4);
        rightPanel.add(but5);
        rightPanel.add(but6);
        rightPanel.add(but7);
        rightPanel.add(but8);
        rightPanel.add(but9);

        frame.pack();
        frame.setVisible(true);
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        Level1();
                        i=0;
                        count.setText(" "+i);
                        frame.setVisible(false);
                        frame.dispose();
                    }
                });
            }
        });

        Level.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        GUIStart();
                        frame.setVisible(false);
                        frame.dispose();
                    }
                });
            }
        });
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        but1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Level1Over();
                but1.setText("X");
            }
        });
        but2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but2.setEnabled(false);
                but2.setText("3");

                i++;
                count.setText("  "+i);
                if (i == 6) {
                    YouWin();
                }

            }
        });
        but3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but3.setEnabled(false);
                but3.setText("2");
                i++;
                count.setText("  "+i);
                if (i == 6) {
                    YouWin();
                }
            }
        });
        but4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but4.setEnabled(false);
                but4.setText("2");
                i++;
                count.setText("  "+i);
                if (i == 6) {
                    YouWin();
                }
            }
        });
        but5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Level1Over();
                but5.setText("X");
            }
        });
        but6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Level1Over();
                but6.setText("X");
            }
        });
        but7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but7.setEnabled(false);
                but7.setText("1");
                i++;
                count.setText("  "+i);
                if (i == 6) {
                    YouWin();
                }
            }
        });
        but8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but8.setEnabled(false);
                but8.setText("2");
                i++;
                count.setText("  "+i);
                if (i == 6) {
                    YouWin();
                }
            }
        });
        but9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but9.setEnabled(false);
                but9.setText("2");
                i++;
                count.setText("  "+i);
                if (i == 6) {
                    YouWin();
                }
            }
        });

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
    private void Level2() {

        JFrame frame = new JFrame("Level 2: "+RLText.getText());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1366, 768);
        JPanel leftPanel = new JPanel();
        JPanel rightPanel = new JPanel();
        frame.getContentPane().add(leftPanel, "West");
        frame.getContentPane().add(rightPanel, "East");
        leftPanel.setSize(100, 100);
        leftPanel.setLayout(new GridLayout(5,1));
        rightPanel.setLayout(new GridLayout(4,4));
        leftPanel.setBackground(Color.BLUE);
        rightPanel.setBackground(Color.WHITE);

        Reset = new JButton("Reset");
        Level = new JButton("Select Level");
        Score = new JLabel(" Score");
        count = new JLabel("   "+i);
        Score.setFont (Score.getFont ().deriveFont (30.0f));
        count.setFont (count.getFont ().deriveFont (40.0f));
        but10 = new JButton("");
        but11= new JButton("");
        but12= new JButton("");
        but13= new JButton("");
        but14= new JButton("");
        but15= new JButton("");
        but16= new JButton("");
        but17= new JButton("");
        but18= new JButton("");
        but19 = new JButton("");
        but20 = new JButton("");
        but21 = new JButton("");
        but22= new JButton("");
        but23= new JButton("");
        but24= new JButton("");
        but25= new JButton("");
        but10.setPreferredSize(new Dimension(100,100));
        Level.setPreferredSize(new Dimension(100,5));
        leftPanel.add(Reset);
        leftPanel.add(Level);

        leftPanel.add(Score);
        leftPanel.add(count);

        rightPanel.add(but10);
        rightPanel.add(but11);
        rightPanel.add(but12);
        rightPanel.add(but13);
        rightPanel.add(but14);
        rightPanel.add(but15);
        rightPanel.add(but16);
        rightPanel.add(but17);
        rightPanel.add(but18);
        rightPanel.add(but19);
        rightPanel.add(but20);
        rightPanel.add(but21);
        rightPanel.add(but22);
        rightPanel.add(but23);
        rightPanel.add(but24);
        rightPanel.add(but25);

        frame.pack();
        frame.setVisible(true);
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        Level2();
                        i=0;
                        count.setText(" "+i);
                        frame.setVisible(false);
                        frame.dispose();
                    }
                });
            }
        });

        Level.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        GUIStart();
                        frame.setVisible(false);
                        frame.dispose();

                    }
                });
            }
        });
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        but10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but10.setEnabled(false);
                but10.setText("1");
                i++;
                count.setText("  "+i);
                if (i == 9) {
                    YouWin2();
                }
            }
        });
        but11.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but11.setEnabled(false);
                but11.setText("1");
                i++;
                count.setText("  "+i);
                if (i == 9) {
                    YouWin2();
                }
            }
        });
        but12.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but12.setEnabled(false);
                but12.setText("2");
                i++;
                count.setText("  "+i);
                if (i == 9) {
                    YouWin2();
                }
            }
        });
        but13.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Level2Over();
                but13.setText("X");
            }
        });
        but14.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but14.setEnabled(false);
                but14.setText("2");
                i++;
                count.setText("  "+i);
                if (i == 9) {
                    YouWin2();
                }
            }
        });
        but15.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Level2Over();
                but15.setText("X");
            }
        });
        but16.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but16.setEnabled(false);
                but16.setText("3");
                i++;
                count.setText("  "+i);
                if (i == 9) {
                    YouWin2();
                }
            }
        });
        but17.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but17.setEnabled(false);
                but17.setText("2");
                i++;
                count.setText("  "+i);
                if (i == 9) {
                    YouWin2();
                }
            }
        });
        but18.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Level2Over();
                but18.setText("X");
            }
        });
        but19.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but19.setEnabled(false);
                but19.setText("5");
                i++;
                count.setText("  "+i);
                if (i == 9) {
                    YouWin2();
                }
            }
        });
        but20.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Level2Over();
                but20.setText("X");
            }
        });
        but21.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but21.setEnabled(false);
                but21.setText("2");
                i++;
                count.setText("  "+i);
                if (i == 9) {
                    YouWin2();
                }
            }
        });
        but22.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Level2Over();
                but22.setText("X");
            }
        });
        but23.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Level2Over();
                but23.setText("X");
            }
        });
        but24.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                but24.setEnabled(false);
                but24.setText("3");
                i++;
                count.setText("  "+i);
                if (i == 9) {
                    YouWin2();
                }
            }
        });
        but25.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Level2Over();
                but25.setText("X");
            }
        });
    }

    public void Level1Over(){
        but1.setEnabled(false);
        but2.setEnabled(false);
        but3.setEnabled(false);
        but4.setEnabled(false);
        but5.setEnabled(false);
        but6.setEnabled(false);
        but7.setEnabled(false);
        but8.setEnabled(false);
        but9.setEnabled(false);
        but1.setText("");
        but2.setText("");
        but3.setText("");
        but4.setText("");
        but5.setText("");
        but6.setText("");
        but7.setText("");
        but8.setText("");
        but9.setText("");
        Score.setText("Game");
        count.setText("Over");
    }
    public void YouWin(){
        but1.setEnabled(false);
        but2.setEnabled(false);
        but3.setEnabled(false);
        but4.setEnabled(false);
        but5.setEnabled(false);
        but6.setEnabled(false);
        but7.setEnabled(false);
        but8.setEnabled(false);
        but9.setEnabled(false);
        but1.setText("X");
        but2.setText("");
        but3.setText("");
        but4.setText("");
        but5.setText("X");
        but6.setText("X");
        but7.setText("");
        but8.setText("");
        but9.setText("");
        Score.setText("You");
        count.setText("Win");
    }
    public void Level2Over(){
        but10.setEnabled(false);
        but11.setEnabled(false);
        but12.setEnabled(false);
        but13.setEnabled(false);
        but14.setEnabled(false);
        but15.setEnabled(false);
        but16.setEnabled(false);
        but17.setEnabled(false);
        but18.setEnabled(false);
        but19.setEnabled(false);
        but20.setEnabled(false);
        but21.setEnabled(false);
        but22.setEnabled(false);
        but23.setEnabled(false);
        but24.setEnabled(false);
        but25.setEnabled(false);

        but10.setText("");
        but11.setText("");
        but12.setText("");
        but13.setText("");
        but14.setText("");
        but15.setText("");
        but16.setText("");
        but17.setText("");
        but18.setText("");
        but19.setText("");
        but20.setText("");
        but21.setText("");
        but22.setText("");
        but23.setText("");
        but24.setText("");
        but25.setText("");

        Score.setText("Game");
        count.setText("Over");
    }
    public void YouWin2(){
        but10.setEnabled(false);
        but11.setEnabled(false);
        but12.setEnabled(false);
        but13.setEnabled(false);
        but14.setEnabled(false);
        but15.setEnabled(false);
        but16.setEnabled(false);
        but17.setEnabled(false);
        but18.setEnabled(false);
        but19.setEnabled(false);
        but20.setEnabled(false);
        but21.setEnabled(false);
        but22.setEnabled(false);
        but23.setEnabled(false);
        but24.setEnabled(false);
        but25.setEnabled(false);

        but10.setText("");
        but11.setText("");
        but12.setText("");
        but13.setText("X");
        but14.setText("");
        but15.setText("X");
        but16.setText("");
        but17.setText("");
        but18.setText("X");
        but19.setText("");
        but20.setText("X");
        but21.setText("");
        but22.setText("X");
        but23.setText("X");
        but24.setText("");
        but25.setText("X");

        Score.setText("You");
        count.setText("Win");
    }

}
